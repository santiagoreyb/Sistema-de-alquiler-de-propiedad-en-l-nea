package negocio;
/**
 *
 * @author Santiago Camilo Rey Benavides
 */
public class constantes {

    public static final String USERNAME = "is146615";
    public static final String PASSWORD = "7tX7ydxS_z";
    public static final String THINCONN = "jdbc:oracle:thin:@orion.javeriana.edu.co:1521/LAB";

}
